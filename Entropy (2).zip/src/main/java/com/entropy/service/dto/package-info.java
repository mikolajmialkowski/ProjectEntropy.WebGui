/**
 * Data Transfer Objects.
 */
package com.entropy.service.dto;
