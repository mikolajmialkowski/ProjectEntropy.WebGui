/**
 * Service layer beans.
 */
package com.entropy.service;
