/**
 * Spring Security configuration.
 */
package com.entropy.security;
