/**
 * JPA domain objects.
 */
package com.entropy.domain;
