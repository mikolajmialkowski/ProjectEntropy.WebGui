/**
 * Spring Data JPA repositories.
 */
package com.entropy.repository;
