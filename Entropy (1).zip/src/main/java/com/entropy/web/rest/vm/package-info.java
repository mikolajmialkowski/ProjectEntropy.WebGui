/**
 * View Models used by Spring MVC REST controllers.
 */
package com.entropy.web.rest.vm;
